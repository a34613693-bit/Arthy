<?php
require __DIR__ . '/config.php';
$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare('SELECT i.*, c.company_name, c.website, c.description AS company_desc FROM internships i JOIN companies c ON c.id = i.company_id WHERE i.id = ?');
$st->execute([$id]); $i = $st->fetch();
if (!$i) { http_response_code(404); die('Internship not found.'); }
$u = current_user();
$isOpen = $i['status'] === 'open' && (!$i['deadline'] || $i['deadline'] >= date('Y-m-d'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    require_role('student');
    if (!$isOpen) { flash('error', 'This internship is no longer accepting applications.'); redirect("internship.php?id=$id"); }
    $sid = $u['student_id'];
    $pr = db()->prepare('SELECT college, degree FROM students WHERE id = ?'); $pr->execute([$sid]); $pr = $pr->fetch();
    if (!$pr['college'] || !$pr['degree']) { flash('error', 'Please complete your profile (college and degree) before applying.'); redirect(BASE . 'student/profile.php'); }
    try {
        db()->prepare('INSERT INTO applications (internship_id, student_id, cover_letter) VALUES (?,?,?)')
            ->execute([$id, $sid, trim($_POST['cover_letter'] ?? '')]);
        flash('success', 'Application submitted successfully!');
        redirect(BASE . 'student/applications.php');
    } catch (PDOException $ex) {
        flash('error', 'You have already applied to this internship.'); redirect("internship.php?id=$id");
    }
}
$already = false;
if ($u && $u['role'] === 'student') {
    $a = db()->prepare('SELECT status FROM applications WHERE internship_id = ? AND student_id = ?');
    $a->execute([$id, $u['student_id']]); $already = $a->fetch();
}
$pageTitle = $i['title'];
include __DIR__ . '/includes/header.php';
?>
<div class="card">
  <h2><?= e($i['title']) ?></h2>
  <p class="company"><?= e($i['company_name']) ?> · <?= e($i['location']) ?></p>
  <dl class="details">
    <dt>Duration</dt><dd><?= e($i['duration']) ?></dd>
    <dt>Stipend</dt><dd><?= e($i['stipend'] ?: 'Not specified') ?></dd>
    <dt>Eligibility</dt><dd><?= e($i['eligibility']) ?></dd>
    <dt>Skills required</dt><dd><?php foreach (array_filter(array_map('trim', explode(',', $i['skills_required']))) as $s): ?><span class="chip"><?= e($s) ?></span><?php endforeach; ?></dd>
    <dt>Apply by</dt><dd><?= $i['deadline'] ? e(date('d M Y', strtotime($i['deadline']))) : 'Open' ?></dd>
  </dl>
  <h3>About the internship</h3>
  <p><?= nl2br(e($i['description'])) ?></p>
  <?php if ($i['company_desc']): ?><h3>About <?= e($i['company_name']) ?></h3><p><?= nl2br(e($i['company_desc'])) ?></p><?php endif; ?>
</div>

<div class="card">
<?php if (!$u): ?>
  <p><a href="login.php">Login</a> or <a href="register.php">register</a> as a student to apply.</p>
<?php elseif ($u['role'] !== 'student'): ?>
  <p class="muted">Log in with a student account to apply.</p>
<?php elseif ($already): ?>
  <p>You have applied. Current status: <span class="<?= status_class($already['status']) ?>"><?= e($already['status']) ?></span></p>
<?php elseif (!$isOpen): ?>
  <p class="muted">Applications are closed for this internship.</p>
<?php else: ?>
  <h3>Apply now</h3>
  <form method="post">
    <?= csrf_field() ?>
    <label>Cover letter / why are you a good fit?<textarea name="cover_letter" rows="5" maxlength="2000"></textarea></label>
    <button class="btn" type="submit">Submit application</button>
  </form>
<?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
