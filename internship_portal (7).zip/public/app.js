document.addEventListener('DOMContentLoaded', function () {
  // Register form: label swap + password match check
  var type = document.getElementById('type'), label = document.getElementById('nameLabel');
  if (type && label) {
    var sync = function () { label.textContent = type.value === 'company' ? 'Company name' : 'Full name'; };
    type.addEventListener('change', sync); sync();
  }
  var form = document.getElementById('regForm');
  if (form) form.addEventListener('submit', function (e) {
    if (document.getElementById('pw').value !== document.getElementById('pw2').value) {
      e.preventDefault(); alert('Passwords do not match.');
    }
  });
  // Confirm before destructive actions
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('submit', function (e) { if (!confirm(el.dataset.confirm)) e.preventDefault(); });
  });
  // Auto-hide flash messages
  setTimeout(function () { document.querySelectorAll('.alert.success').forEach(function (a) { a.style.display = 'none'; }); }, 5000);
});
