<?php
require __DIR__ . '/../config.php';
require_role('company', 'admin');
$id = (int)($_GET['id'] ?? 0);
$q = db()->prepare('SELECT a.*, i.title, i.company_id, i.skills_required, i.eligibility, c.company_name, s.*, s.id AS sid, a.id AS id, a.status AS status, u.email
    FROM applications a JOIN internships i ON i.id=a.internship_id JOIN companies c ON c.id=i.company_id
    JOIN students s ON s.id=a.student_id JOIN users u ON u.id=s.user_id WHERE a.id=?');
$q->execute([$id]); $a = $q->fetch();
if (!$a || !can_manage((int)$a['company_id'])) { http_response_code(403); die('Access denied.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $new = $_POST['status'] ?? '';
    if (in_array($new, STATUSES, true)) {
        db()->prepare('UPDATE applications SET status=?, remarks=? WHERE id=?')->execute([$new, mb_substr(trim($_POST['remarks'] ?? ''), 0, 500) ?: null, $id]);
        flash('success', "Application marked as $new.");
    }
    redirect("application.php?id=$id");
}
$sk = db()->prepare('SELECT skill_name FROM skills WHERE student_id=? ORDER BY skill_name'); $sk->execute([$a['sid']]); $skills = array_column($sk->fetchAll(), 'skill_name');
$pageTitle = 'Review Application';
include __DIR__ . '/../includes/header.php';
?>
<p><a href="applicants.php">← Back to applicants</a></p>
<div class="card">
  <h2><?= e($a['full_name']) ?> <span class="<?= status_class($a['status']) ?>"><?= e($a['status']) ?></span></h2>
  <p class="company">Applied for <b><?= e($a['title']) ?></b> at <?= e($a['company_name']) ?> on <?= e(date('d M Y', strtotime($a['applied_at']))) ?></p>
  <dl class="details">
    <dt>Email</dt><dd><?= e($a['email']) ?></dd>
    <dt>Phone</dt><dd><?= e($a['phone'] ?: '—') ?></dd>
    <dt>College</dt><dd><?= e($a['college'] ?: '—') ?></dd>
    <dt>Degree / Branch</dt><dd><?= e(trim(($a['degree'] ?: '') . ' ' . ($a['branch'] ?: '')) ?: '—') ?></dd>
    <dt>Year / CGPA</dt><dd><?= e($a['year_of_study'] ?: '—') ?> / <?= e($a['cgpa'] ?: '—') ?></dd>
    <dt>Skills</dt><dd><?php foreach ($skills as $s): ?><span class="chip"><?= e($s) ?></span><?php endforeach; if (!$skills) echo '—'; ?></dd>
    <dt>Resume</dt><dd><?php if ($a['resume_link']): ?><a href="<?= e($a['resume_link']) ?>" target="_blank" rel="noopener noreferrer">Open resume</a><?php else: ?>—<?php endif; ?></dd>
    <dt>Required skills</dt><dd><?= e($a['skills_required']) ?></dd>
    <dt>Eligibility</dt><dd><?= e($a['eligibility']) ?></dd>
  </dl>
  <?php if ($a['bio']): ?><h3>About the student</h3><p><?= nl2br(e($a['bio'])) ?></p><?php endif; ?>
  <h3>Cover letter</h3><p><?= $a['cover_letter'] ? nl2br(e($a['cover_letter'])) : '<span class="muted">Not provided.</span>' ?></p>
</div>
<div class="card">
  <h3>Update application</h3>
  <form method="post">
    <?= csrf_field() ?>
    <label>Status<select name="status"><?php foreach (STATUSES as $s): ?><option <?= $a['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select></label>
    <label>Remarks (visible to student)<textarea name="remarks" rows="3" maxlength="500"><?= e($a['remarks']) ?></textarea></label>
    <button class="btn" type="submit">Save</button>
    <button class="btn ghost" type="submit" name="status" value="Shortlisted">Shortlist</button>
    <button class="btn danger" type="submit" name="status" value="Rejected">Reject</button>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
