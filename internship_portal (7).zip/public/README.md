# College Internship Management Portal (HTML/CSS/JS + PHP + MySQL)

## Setup (XAMPP / WAMP / LAMP, PHP 7.4+ or 8.x)
1. Copy this folder to your web root, e.g. `htdocs/internship_portal`.
2. Start Apache and MySQL, open phpMyAdmin and **import `database.sql`**
   (or `mysql -u root < database.sql`).
3. Edit `config.php`: set `DB_USER`, `DB_PASS`, and `BASE` (the URL path of the folder, e.g. `/internship_portal/`).
4. Visit `http://localhost/internship_portal/install.php` once to create the admin + demo company, then **delete `install.php`**.
5. Open `http://localhost/internship_portal/`.

## Demo logins (created by install.php)
| Role    | Email             | Password     |
|---------|-------------------|--------------|
| Admin   | admin@portal.com  | Admin@123    |
| Company | hr@democorp.com   | Company@123  |
| Student | register via the Register page |

## Structure
- `index.php` browse/search internships, `internship.php` details + apply
- `login.php`, `register.php`, `logout.php` – PHP session authentication (bcrypt hashes)
- `student/` – profile & skills, application tracking
- `company/` – dashboard, internship CRUD, applicants, review/shortlist/reject, students list
- Status flow: Applied → Under Review → Shortlisted → Interview → Selected / Rejected

## Security built in
Prepared statements (PDO), password_hash/verify, session ID regeneration, CSRF tokens on all POST forms,
output escaping, role-based access control, per-company data scoping.
