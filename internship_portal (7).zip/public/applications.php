<?php
require __DIR__ . '/../config.php';
require_role('student');
$st = db()->prepare("SELECT a.*, i.title, i.location, c.company_name FROM applications a
    JOIN internships i ON i.id = a.internship_id JOIN companies c ON c.id = i.company_id
    WHERE a.student_id = ? ORDER BY a.applied_at DESC");
$st->execute([current_user()['student_id']]); $apps = $st->fetchAll();
$flow = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected'];
$pageTitle = 'My Applications';
include __DIR__ . '/../includes/header.php';
?>
<h2>My Applications</h2>
<?php foreach ($apps as $a): ?>
  <div class="card">
    <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px">
      <div>
        <h3 style="margin:0"><a href="../internship.php?id=<?= (int)$a['internship_id'] ?>"><?= e($a['title']) ?></a></h3>
        <p class="company"><?= e($a['company_name']) ?> · <?= e($a['location']) ?></p>
      </div>
      <div><span class="<?= status_class($a['status']) ?>"><?= e($a['status']) ?></span></div>
    </div>
    <div class="timeline">
      <?php
      if ($a['status'] === 'Rejected') { echo '<span class="step bad">Rejected</span>'; }
      else { $pos = array_search($a['status'], $flow);
        foreach ($flow as $n => $step) echo '<span class="step ' . ($n <= $pos ? 'done' : '') . '">' . e($step) . '</span>'; }
      ?>
    </div>
    <p class="muted">Applied on <?= e(date('d M Y', strtotime($a['applied_at']))) ?> · Last updated <?= e(date('d M Y, H:i', strtotime($a['updated_at']))) ?></p>
    <?php if ($a['remarks']): ?><p><b>Remarks:</b> <?= e($a['remarks']) ?></p><?php endif; ?>
  </div>
<?php endforeach; ?>
<?php if (!$apps): ?><div class="card">You haven't applied to any internships yet. <a href="../index.php">Browse internships</a></div><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
