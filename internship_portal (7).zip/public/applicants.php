<?php
require __DIR__ . '/../config.php';
require_role('company', 'admin');
$cid = my_company_id();
$fi = (int)($_GET['internship'] ?? 0); $fs = $_GET['status'] ?? '';

// Quick status update from list
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $aid = (int)$_POST['id']; $new = $_POST['status'] ?? '';
    $r = db()->prepare('SELECT i.company_id FROM applications a JOIN internships i ON i.id=a.internship_id WHERE a.id=?'); $r->execute([$aid]); $r = $r->fetch();
    if ($r && can_manage((int)$r['company_id']) && in_array($new, STATUSES, true)) {
        db()->prepare('UPDATE applications SET status=? WHERE id=?')->execute([$new, $aid]);
        flash('success', "Status updated to $new.");
    }
    redirect('applicants.php?' . http_build_query(['internship' => $fi ?: '', 'status' => $fs]));
}
$sql = 'SELECT a.id, a.status, a.applied_at, s.full_name, s.college, s.cgpa, i.title, i.id AS iid, c.company_name
        FROM applications a JOIN students s ON s.id=a.student_id JOIN internships i ON i.id=a.internship_id JOIN companies c ON c.id=i.company_id WHERE 1=1';
$p = [];
if ($cid) { $sql .= ' AND i.company_id=?'; $p[] = $cid; }
if ($fi) { $sql .= ' AND i.id=?'; $p[] = $fi; }
if (in_array($fs, STATUSES, true)) { $sql .= ' AND a.status=?'; $p[] = $fs; }
$sql .= ' ORDER BY a.applied_at DESC';
$st = db()->prepare($sql); $st->execute($p); $rows = $st->fetchAll();
$il = db()->prepare('SELECT id, title FROM internships' . ($cid ? ' WHERE company_id=?' : '') . ' ORDER BY title'); $il->execute($cid ? [$cid] : []); $il = $il->fetchAll();
$pageTitle = 'Applicants';
include __DIR__ . '/../includes/header.php';
?>
<h2>Applicants</h2>
<form class="filters" method="get">
  <select name="internship"><option value="">All internships</option>
    <?php foreach ($il as $x): ?><option value="<?= (int)$x['id'] ?>" <?= $fi === (int)$x['id'] ? 'selected' : '' ?>><?= e($x['title']) ?></option><?php endforeach; ?></select>
  <select name="status"><option value="">All statuses</option>
    <?php foreach (STATUSES as $s): ?><option <?= $fs === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select>
  <button class="btn" type="submit">Filter</button>
</form>
<div class="table-wrap"><table>
  <tr><th>Student</th><th>College</th><th>CGPA</th><th>Internship</th><th>Applied</th><th>Status</th><th>Actions</th></tr>
  <?php foreach ($rows as $r): ?>
  <tr>
    <td><b><?= e($r['full_name']) ?></b></td><td><?= e($r['college'] ?: '—') ?></td><td><?= e($r['cgpa'] ?: '—') ?></td>
    <td><?= e($r['title']) ?></td><td><?= e(date('d M Y', strtotime($r['applied_at']))) ?></td>
    <td><span class="<?= status_class($r['status']) ?>"><?= e($r['status']) ?></span></td>
    <td>
      <form method="post" class="inline-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
        <select name="status"><?php foreach (STATUSES as $s): ?><option <?= $r['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select>
        <button class="btn small">Update</button>
        <a class="btn small ghost" href="application.php?id=<?= (int)$r['id'] ?>">Review</a>
      </form>
    </td>
  </tr>
  <?php endforeach; if (!$rows) echo '<tr><td colspan="7" class="muted">No applicants found.</td></tr>'; ?>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
