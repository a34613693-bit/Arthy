<?php require_once __DIR__ . '/../config.php'; $u = current_user(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle ?? 'Internship Portal') ?> · InternHub</title>
<link rel="stylesheet" href="<?= BASE ?>assets/css/style.css">
</head>
<body>
<header class="topbar">
  <a class="brand" href="<?= BASE ?>index.php">Intern<span>Hub</span></a>
  <button class="menu-btn" type="button" aria-label="Menu" onclick="document.getElementById('nav').classList.toggle('open')">☰</button>
  <nav id="nav">
    <a href="<?= BASE ?>index.php">Internships</a>
    <?php if (!$u): ?>
      <a href="<?= BASE ?>login.php">Login</a>
      <a class="btn small" href="<?= BASE ?>register.php">Register</a>
    <?php elseif ($u['role'] === 'student'): ?>
      <a href="<?= BASE ?>student/applications.php">My Applications</a>
      <a href="<?= BASE ?>student/profile.php">My Profile</a>
      <a href="<?= BASE ?>logout.php">Logout</a>
    <?php else: ?>
      <a href="<?= BASE ?>company/dashboard.php">Dashboard</a>
      <a href="<?= BASE ?>company/internships.php">Manage Internships</a>
      <a href="<?= BASE ?>company/applicants.php">Applicants</a>
      <a href="<?= BASE ?>company/students.php">Students</a>
      <a href="<?= BASE ?>logout.php">Logout</a>
    <?php endif; ?>
  </nav>
</header>
<main class="container">
<?php foreach ($_SESSION['flash'] ?? [] as [$t, $m]): ?>
  <div class="alert <?= e($t) ?>"><?= e($m) ?></div>
<?php endforeach; unset($_SESSION['flash']); ?>
