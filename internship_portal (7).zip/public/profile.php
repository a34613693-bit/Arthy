<?php
require __DIR__ . '/../config.php';
require_role('student');
$sid = current_user()['student_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    if ($action === 'profile') {
        $year = ($_POST['year_of_study'] ?? '') !== '' ? max(1, min(6, (int)$_POST['year_of_study'])) : null;
        $cgpa = ($_POST['cgpa'] ?? '') !== '' ? max(0, min(10, (float)$_POST['cgpa'])) : null;
        $resume = trim($_POST['resume_link'] ?? '');
        if ($resume !== '' && !filter_var($resume, FILTER_VALIDATE_URL)) { flash('error', 'Resume link must be a valid URL.'); redirect('profile.php'); }
        $name = trim($_POST['full_name'] ?? '');
        if ($name === '') { flash('error', 'Name cannot be empty.'); redirect('profile.php'); }
        db()->prepare('UPDATE students SET full_name=?, phone=?, college=?, degree=?, branch=?, year_of_study=?, cgpa=?, bio=?, resume_link=? WHERE id=?')
            ->execute([$name, trim($_POST['phone'] ?? ''), trim($_POST['college'] ?? ''), trim($_POST['degree'] ?? ''), trim($_POST['branch'] ?? ''), $year, $cgpa, trim($_POST['bio'] ?? ''), $resume ?: null, $sid]);
        $_SESSION['user']['name'] = $name;
        flash('success', 'Profile updated.');
    } elseif ($action === 'add_skill') {
        foreach (array_filter(array_map('trim', explode(',', $_POST['skill'] ?? ''))) as $s) {
            db()->prepare('INSERT IGNORE INTO skills (student_id, skill_name) VALUES (?,?)')->execute([$sid, mb_substr($s, 0, 60)]);
        }
        flash('success', 'Skills updated.');
    } elseif ($action === 'del_skill') {
        db()->prepare('DELETE FROM skills WHERE id=? AND student_id=?')->execute([(int)$_POST['skill_id'], $sid]);
        flash('success', 'Skill removed.');
    }
    redirect('profile.php');
}
$s = db()->prepare('SELECT s.*, u.email FROM students s JOIN users u ON u.id = s.user_id WHERE s.id = ?'); $s->execute([$sid]); $s = $s->fetch();
$sk = db()->prepare('SELECT * FROM skills WHERE student_id = ? ORDER BY skill_name'); $sk->execute([$sid]); $skills = $sk->fetchAll();
$pageTitle = 'My Profile';
include __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>My Profile</h2>
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="action" value="profile">
    <div class="form-row">
      <label>Full name<input name="full_name" value="<?= e($s['full_name']) ?>" required></label>
      <label>Email<input value="<?= e($s['email']) ?>" disabled></label>
    </div>
    <div class="form-row">
      <label>Phone<input name="phone" value="<?= e($s['phone']) ?>"></label>
      <label>College / University<input name="college" value="<?= e($s['college']) ?>"></label>
    </div>
    <div class="form-row">
      <label>Degree (e.g. B.Tech)<input name="degree" value="<?= e($s['degree']) ?>"></label>
      <label>Branch / Major<input name="branch" value="<?= e($s['branch']) ?>"></label>
    </div>
    <div class="form-row">
      <label>Year of study<input type="number" name="year_of_study" min="1" max="6" value="<?= e($s['year_of_study']) ?>"></label>
      <label>CGPA (0-10)<input type="number" step="0.01" min="0" max="10" name="cgpa" value="<?= e($s['cgpa']) ?>"></label>
    </div>
    <label>Resume link (Drive / LinkedIn / portfolio URL)<input type="url" name="resume_link" value="<?= e($s['resume_link']) ?>"></label>
    <label>About me<textarea name="bio" rows="4"><?= e($s['bio']) ?></textarea></label>
    <button class="btn" type="submit">Save profile</button>
  </form>
</div>
<div class="card">
  <h2>Skills</h2>
  <p><?php foreach ($skills as $k): ?>
    <span class="chip"><?= e($k['skill_name']) ?>
      <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="del_skill"><input type="hidden" name="skill_id" value="<?= (int)$k['id'] ?>"><button title="Remove">×</button></form>
    </span>
  <?php endforeach; if (!$skills) echo '<span class="muted">No skills added yet.</span>'; ?></p>
  <form method="post" class="inline-form">
    <?= csrf_field() ?><input type="hidden" name="action" value="add_skill">
    <input name="skill" placeholder="e.g. Python, SQL, React (comma separated)" required style="flex:1">
    <button class="btn" type="submit">Add</button>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
