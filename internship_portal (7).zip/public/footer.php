</main>
<footer class="footer">© <?= date('Y') ?> InternHub · College Internship Management Portal</footer>
<script src="<?= BASE ?>assets/js/app.js"></script>
</body>
</html>
