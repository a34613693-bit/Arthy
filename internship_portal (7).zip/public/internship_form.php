<?php
require __DIR__ . '/../config.php';
require_role('company', 'admin');
$id = (int)($_GET['id'] ?? 0);
$d = ['title'=>'','description'=>'','skills_required'=>'','duration'=>'','eligibility'=>'','location'=>'Remote','stipend'=>'','deadline'=>'','status'=>'open','company_id'=>my_company_id()];
if ($id) {
    $st = db()->prepare('SELECT * FROM internships WHERE id=?'); $st->execute([$id]); $row = $st->fetch();
    if (!$row || !can_manage((int)$row['company_id'])) { http_response_code(403); die('Access denied.'); }
    $d = $row;
}
$companies = current_user()['role'] === 'admin' ? db()->query('SELECT id, company_name FROM companies ORDER BY company_name')->fetchAll() : [];
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach (['title','description','skills_required','duration','eligibility','location','stipend','deadline'] as $f) $d[$f] = trim($_POST[$f] ?? '');
    $d['status'] = ($_POST['status'] ?? 'open') === 'closed' ? 'closed' : 'open';
    $companyId = my_company_id() ?? (int)($_POST['company_id'] ?? 0);
    $d['company_id'] = $companyId;
    foreach (['title'=>'Title','description'=>'Description','skills_required'=>'Skills','duration'=>'Duration','eligibility'=>'Eligibility'] as $f => $n)
        if ($d[$f] === '') $errors[] = "$n is required.";
    if (!$companyId) $errors[] = 'Select a company.';
    if ($d['deadline'] !== '' && !strtotime($d['deadline'])) $errors[] = 'Invalid deadline.';
    if (!$errors) {
        $vals = [$companyId, $d['title'], $d['description'], $d['skills_required'], $d['duration'], $d['eligibility'], $d['location'] ?: 'Remote', $d['stipend'] ?: null, $d['deadline'] ?: null, $d['status']];
        if ($id) {
            $vals[] = $id;
            db()->prepare('UPDATE internships SET company_id=?, title=?, description=?, skills_required=?, duration=?, eligibility=?, location=?, stipend=?, deadline=?, status=? WHERE id=?')->execute($vals);
            flash('success', 'Internship updated.');
        } else {
            db()->prepare('INSERT INTO internships (company_id,title,description,skills_required,duration,eligibility,location,stipend,deadline,status) VALUES (?,?,?,?,?,?,?,?,?,?)')->execute($vals);
            flash('success', 'Internship published.');
        }
        redirect('internships.php');
    }
}
$pageTitle = $id ? 'Edit Internship' : 'Post Internship';
include __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2><?= $id ? 'Edit' : 'Post' ?> internship</h2>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post">
    <?= csrf_field() ?>
    <?php if ($companies): ?>
    <label>Company<select name="company_id"><option value="">— select —</option>
      <?php foreach ($companies as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$d['company_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['company_name']) ?></option><?php endforeach; ?>
    </select></label>
    <?php endif; ?>
    <label>Title<input name="title" value="<?= e($d['title']) ?>" required></label>
    <label>Description<textarea name="description" rows="6" required><?= e($d['description']) ?></textarea></label>
    <label>Skills required (comma separated)<input name="skills_required" value="<?= e($d['skills_required']) ?>" placeholder="PHP, MySQL, JavaScript" required></label>
    <div class="form-row">
      <label>Duration<input name="duration" value="<?= e($d['duration']) ?>" placeholder="3 months" required></label>
      <label>Location<input name="location" value="<?= e($d['location']) ?>"></label>
    </div>
    <label>Eligibility<input name="eligibility" value="<?= e($d['eligibility']) ?>" placeholder="B.Tech 3rd year, CGPA 7+" required></label>
    <div class="form-row">
      <label>Stipend<input name="stipend" value="<?= e($d['stipend']) ?>" placeholder="₹10,000/month"></label>
      <label>Application deadline<input type="date" name="deadline" value="<?= e($d['deadline']) ?>"></label>
    </div>
    <label>Status<select name="status"><option value="open" <?= $d['status']==='open'?'selected':'' ?>>Open</option><option value="closed" <?= $d['status']==='closed'?'selected':'' ?>>Closed</option></select></label>
    <button class="btn" type="submit"><?= $id ? 'Save changes' : 'Publish' ?></button>
    <a class="btn ghost" href="internships.php">Cancel</a>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
