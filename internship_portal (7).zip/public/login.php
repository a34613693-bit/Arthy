<?php
require __DIR__ . '/config.php';
if (current_user()) { redirect(BASE . (is_staff() ? 'company/dashboard.php' : 'index.php')); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $stmt = db()->prepare('SELECT * FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user && password_verify($_POST['password'] ?? '', $user['password'])) {
        session_regenerate_id(true);
        $sess = ['id' => (int)$user['id'], 'email' => $user['email'], 'role' => $user['role']];
        if ($user['role'] === 'student') {
            $s = db()->prepare('SELECT id, full_name FROM students WHERE user_id = ?');
            $s->execute([$user['id']]); $r = $s->fetch();
            $sess['student_id'] = (int)$r['id']; $sess['name'] = $r['full_name'];
        } elseif ($user['role'] === 'company') {
            $s = db()->prepare('SELECT id, company_name FROM companies WHERE user_id = ?');
            $s->execute([$user['id']]); $r = $s->fetch();
            $sess['company_id'] = (int)$r['id']; $sess['name'] = $r['company_name'];
        } else { $sess['name'] = 'Administrator'; }
        $_SESSION['user'] = $sess;
        redirect(BASE . ($user['role'] === 'student' ? 'index.php' : 'company/dashboard.php'));
    }
    $error = 'Invalid email or password.';
}
$pageTitle = 'Login';
include __DIR__ . '/includes/header.php';
?>
<div class="card narrow">
  <h2>Login</h2>
  <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <label>Email<input type="email" name="email" required autofocus></label>
    <label>Password<input type="password" name="password" required></label>
    <button class="btn" type="submit">Login</button>
  </form>
  <p class="muted">No account? <a href="register.php">Register here</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
