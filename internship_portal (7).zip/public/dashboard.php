<?php
require __DIR__ . '/../config.php';
require_role('company', 'admin');
$cid = my_company_id();
$scope = $cid ? ' AND i.company_id = ' . (int)$cid : '';

$counts = array_fill_keys(STATUSES, 0);
foreach (db()->query("SELECT a.status, COUNT(*) n FROM applications a JOIN internships i ON i.id=a.internship_id WHERE 1=1 $scope GROUP BY a.status") as $r) $counts[$r['status']] = (int)$r['n'];
$totalInt = (int)db()->query("SELECT COUNT(*) FROM internships i WHERE 1=1 $scope")->fetchColumn();
$openInt  = (int)db()->query("SELECT COUNT(*) FROM internships i WHERE status='open' $scope")->fetchColumn();
$students = (int)db()->query('SELECT COUNT(*) FROM students')->fetchColumn();
$recent = db()->query("SELECT a.id, a.status, a.applied_at, s.full_name, i.title FROM applications a
    JOIN students s ON s.id=a.student_id JOIN internships i ON i.id=a.internship_id WHERE 1=1 $scope
    ORDER BY a.applied_at DESC LIMIT 8")->fetchAll();
$pageTitle = 'Dashboard';
include __DIR__ . '/../includes/header.php';
?>
<h2>Welcome, <?= e(current_user()['name']) ?></h2>
<div class="stats">
  <div class="stat"><b><?= $totalInt ?></b>Internships</div>
  <div class="stat"><b><?= $openInt ?></b>Open</div>
  <div class="stat"><b><?= array_sum($counts) ?></b>Applications</div>
  <div class="stat"><b><?= $students ?></b>Registered students</div>
</div>
<div class="stats">
  <?php foreach (STATUSES as $s): ?><div class="stat"><b><?= $counts[$s] ?></b><span class="<?= status_class($s) ?>"><?= e($s) ?></span></div><?php endforeach; ?>
</div>
<p><a class="btn" href="internship_form.php">+ Post new internship</a></p>
<h3>Recent applications</h3>
<div class="table-wrap"><table>
  <tr><th>Student</th><th>Internship</th><th>Status</th><th>Applied</th><th></th></tr>
  <?php foreach ($recent as $r): ?>
  <tr><td><?= e($r['full_name']) ?></td><td><?= e($r['title']) ?></td><td><span class="<?= status_class($r['status']) ?>"><?= e($r['status']) ?></span></td>
      <td><?= e(date('d M Y', strtotime($r['applied_at']))) ?></td><td><a href="application.php?id=<?= (int)$r['id'] ?>">Review</a></td></tr>
  <?php endforeach; if (!$recent) echo '<tr><td colspan="5" class="muted">No applications yet.</td></tr>'; ?>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
