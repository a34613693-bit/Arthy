<?php
require __DIR__ . '/config.php';
if (current_user()) { redirect(BASE . 'index.php'); }
$errors = []; $old = $_POST;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $type  = ($_POST['type'] ?? 'student') === 'company' ? 'company' : 'student';
    $name  = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';
    if ($name === '') $errors[] = 'Name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (strlen($pass) < 8) $errors[] = 'Password must be at least 8 characters.';
    if ($pass !== ($_POST['confirm'] ?? '')) $errors[] = 'Passwords do not match.';
    if (!$errors) {
        $chk = db()->prepare('SELECT 1 FROM users WHERE email = ?'); $chk->execute([$email]);
        if ($chk->fetch()) { $errors[] = 'That email is already registered.'; }
    }
    if (!$errors) {
        $pdo = db(); $pdo->beginTransaction();
        try {
            $pdo->prepare('INSERT INTO users (email,password,role) VALUES (?,?,?)')
                ->execute([$email, password_hash($pass, PASSWORD_DEFAULT), $type]);
            $uid = $pdo->lastInsertId();
            if ($type === 'student') {
                $pdo->prepare('INSERT INTO students (user_id, full_name) VALUES (?,?)')->execute([$uid, $name]);
            } else {
                $pdo->prepare('INSERT INTO companies (user_id, company_name) VALUES (?,?)')->execute([$uid, $name]);
            }
            $pdo->commit();
            flash('success', 'Registration successful. Please log in.');
            redirect(BASE . 'login.php');
        } catch (Throwable $ex) { $pdo->rollBack(); $errors[] = 'Could not register. Please try again.'; }
    }
}
$pageTitle = 'Register';
include __DIR__ . '/includes/header.php';
?>
<div class="card narrow">
  <h2>Create an account</h2>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" id="regForm">
    <?= csrf_field() ?>
    <label>I am a
      <select name="type" id="type">
        <option value="student" <?= ($old['type'] ?? '') !== 'company' ? 'selected' : '' ?>>Student</option>
        <option value="company" <?= ($old['type'] ?? '') === 'company' ? 'selected' : '' ?>>Company</option>
      </select>
    </label>
    <label><span id="nameLabel">Full name</span><input name="name" value="<?= e($old['name'] ?? '') ?>" required></label>
    <label>Email<input type="email" name="email" value="<?= e($old['email'] ?? '') ?>" required></label>
    <label>Password (min 8 characters)<input type="password" name="password" id="pw" minlength="8" required></label>
    <label>Confirm password<input type="password" name="confirm" id="pw2" required></label>
    <button class="btn" type="submit">Register</button>
  </form>
  <p class="muted">Already registered? <a href="login.php">Login</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
