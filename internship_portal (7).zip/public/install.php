<?php
// Run ONCE in the browser after importing database.sql, then DELETE this file.
require __DIR__ . '/config.php';
$pdo = db();
$out = [];
if (!$pdo->query("SELECT 1 FROM users WHERE role='admin' LIMIT 1")->fetch()) {
    $pdo->prepare("INSERT INTO users (email,password,role) VALUES (?,?,'admin')")
        ->execute(['admin@portal.com', password_hash('Admin@123', PASSWORD_DEFAULT)]);
    $out[] = 'Admin created: admin@portal.com / Admin@123';
}
if (!$pdo->query("SELECT 1 FROM users WHERE email='hr@democorp.com'")->fetch()) {
    $pdo->prepare("INSERT INTO users (email,password,role) VALUES (?,?,'company')")
        ->execute(['hr@democorp.com', password_hash('Company@123', PASSWORD_DEFAULT)]);
    $uid = $pdo->lastInsertId();
    $pdo->prepare("INSERT INTO companies (user_id,company_name,website,description) VALUES (?,?,?,?)")
        ->execute([$uid, 'Demo Corp', 'https://example.com', 'Sample company for testing.']);
    $cid = $pdo->lastInsertId();
    $ins = $pdo->prepare("INSERT INTO internships (company_id,title,description,skills_required,duration,eligibility,location,stipend,deadline) VALUES (?,?,?,?,?,?,?,?,DATE_ADD(CURDATE(), INTERVAL 60 DAY))");
    $ins->execute([$cid, 'Web Development Intern', "Build and maintain features for our web apps.\nWork with a mentor on real projects.", 'HTML, CSS, JavaScript, PHP', '3 months', 'B.Tech/BCA, 2nd year or above, CGPA 6.5+', 'Remote', '₹10,000/month']);
    $ins->execute([$cid, 'Data Analyst Intern', "Clean data, build dashboards and present insights.", 'SQL, Excel, Python', '6 months', 'Any graduate stream, final year', 'Bengaluru', '₹15,000/month']);
    $out[] = 'Demo company created: hr@democorp.com / Company@123 (with 2 sample internships)';
}
echo '<pre>' . e($out ? implode("\n", $out) : 'Nothing to do - already installed.') . "\n\nNow DELETE install.php.</pre>";
