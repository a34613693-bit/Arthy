<?php
require __DIR__ . '/../config.php';
require_role('company', 'admin');
$cid = my_company_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    $row = db()->prepare('SELECT company_id, status FROM internships WHERE id=?'); $row->execute([$id]); $row = $row->fetch();
    if ($row && can_manage((int)$row['company_id'])) {
        if ($_POST['action'] === 'toggle') {
            db()->prepare('UPDATE internships SET status=? WHERE id=?')->execute([$row['status'] === 'open' ? 'closed' : 'open', $id]);
            flash('success', 'Internship status changed.');
        } elseif ($_POST['action'] === 'delete') {
            db()->prepare('DELETE FROM internships WHERE id=?')->execute([$id]);
            flash('success', 'Internship deleted.');
        }
    }
    redirect('internships.php');
}
$sql = 'SELECT i.*, c.company_name, (SELECT COUNT(*) FROM applications a WHERE a.internship_id=i.id) AS apps
        FROM internships i JOIN companies c ON c.id=i.company_id' . ($cid ? ' WHERE i.company_id=' . (int)$cid : '') . ' ORDER BY i.created_at DESC';
$rows = db()->query($sql)->fetchAll();
$pageTitle = 'Manage Internships';
include __DIR__ . '/../includes/header.php';
?>
<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
  <h2>Manage Internships</h2><a class="btn" href="internship_form.php">+ Post new internship</a>
</div>
<div class="table-wrap"><table>
  <tr><th>Title</th><th>Company</th><th>Duration</th><th>Deadline</th><th>Status</th><th>Applicants</th><th>Actions</th></tr>
  <?php foreach ($rows as $r): ?>
  <tr>
    <td><b><?= e($r['title']) ?></b></td><td><?= e($r['company_name']) ?></td><td><?= e($r['duration']) ?></td>
    <td><?= $r['deadline'] ? e(date('d M Y', strtotime($r['deadline']))) : '—' ?></td>
    <td><span class="badge <?= $r['status'] === 'open' ? 's-selected' : 's-rejected' ?>"><?= e(ucfirst($r['status'])) ?></span></td>
    <td><a href="applicants.php?internship=<?= (int)$r['id'] ?>"><?= (int)$r['apps'] ?></a></td>
    <td class="actions">
      <a class="btn small ghost" href="internship_form.php?id=<?= (int)$r['id'] ?>">Edit</a>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="action" value="toggle"><button class="btn small ghost"><?= $r['status'] === 'open' ? 'Close' : 'Reopen' ?></button></form>
      <form method="post" data-confirm="Delete this internship and all its applications?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="action" value="delete"><button class="btn small danger">Delete</button></form>
    </td>
  </tr>
  <?php endforeach; if (!$rows) echo '<tr><td colspan="7" class="muted">No internships posted yet.</td></tr>'; ?>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
