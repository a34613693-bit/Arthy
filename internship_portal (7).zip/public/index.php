<?php
session_start();

if (!isset($_SESSION['users'])) {
    $_SESSION['users'] = [];
}

$page = $_GET['page'] ?? 'home';
$message = '';

if (isset($_GET['logout'])) {
    unset($_SESSION['logged_in'], $_SESSION['email'], $_SESSION['name']);
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)
            || strlen($password) < 6) {
            $message = 'Please enter valid details. Password must have 6 characters.';
            $page = 'register';
        } elseif (isset($_SESSION['users'][$email])) {
            $message = 'Email already registered. Please login.';
            $page = 'login';
        } else {
            $_SESSION['users'][$email] = [
                'name' => $name,
                'password' => password_hash($password, PASSWORD_DEFAULT)
            ];

            $_SESSION['notice'] = 'Registration Successful! Please Login.';
            header('Location: index.php?page=login');
            exit;
        }
    }

    if ($action === 'login') {
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        if (isset($_SESSION['users'][$email]) &&
            password_verify($password, $_SESSION['users'][$email]['password'])) {

            session_regenerate_id(true);
            $_SESSION['logged_in'] = true;
            $_SESSION['email'] = $email;
            $_SESSION['name'] = $_SESSION['users'][$email]['name'];

            $_SESSION['notice'] = 'Login Successful! Welcome to Dashboard.';
            header('Location: index.php?page=dashboard');
            exit;
        } else {
            $message = 'Invalid Email or Password!';
            $page = 'login';
        }
    }
}

if ($page === 'dashboard' && empty($_SESSION['logged_in'])) {
    $page = 'login';
    $message = 'Please login to access Dashboard.';
}

if (isset($_SESSION['notice'])) {
    $message = $_SESSION['notice'];
    unset($_SESSION['notice']);
}

function h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>College Internship Portal</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #edf6ff;
    color: #17345f;
}

header {
    background: #102e59;
    color: white;
    padding: 20px 7%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.logo {
    font-size: 23px;
    font-weight: bold;
}

nav {
    display: flex;
    flex-wrap: wrap;
    gap: 18px;
}

nav a {
    color: white;
    text-decoration: none;
    font-weight: bold;
}

nav a:hover {
    color: #7dd3fc;
}

.hero {
    min-height: 470px;
    padding: 55px 8%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 35px;
    background: linear-gradient(135deg, #c9e7ff, #f8fbff);
}

.hero-content {
    flex: 1;
    min-width: 260px;
}

.hero h1 {
    font-size: clamp(32px, 4vw, 46px);
    color: #12396d;
    margin-bottom: 20px;
}

.hero p {
    line-height: 1.8;
    color: #536b85;
    margin-bottom: 25px;
}

.hero img {
    width: 100%;
    max-width: 440px;
    height: 290px;
    object-fit: cover;
    border-radius: 20px;
    box-shadow: 0 10px 30px #b1cfe9;
}

.btn {
    display: inline-block;
    padding: 13px 22px;
    background: #174c91;
    color: white;
    border: none;
    border-radius: 7px;
    text-decoration: none;
    font-weight: bold;
    cursor: pointer;
    margin: 5px;
}

.btn:hover {
    background: #2468b5;
    transform: translateY(-2px);
}

.features {
    padding: 55px 7%;
    text-align: center;
}

.features h2 {
    margin-bottom: 30px;
    font-size: 30px;
}

.cards {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 22px;
}

.card {
    width: 250px;
    background: white;
    padding: 27px 22px;
    border-radius: 15px;
    box-shadow: 0 6px 22px #d1e2f3;
    transition: 0.3s;
}

.card:hover {
    transform: translateY(-5px);
}

.card .icon {
    font-size: 40px;
    margin-bottom: 15px;
}

.card h3 {
    color: #174c91;
    margin-bottom: 12px;
}

.card p {
    color: #65778d;
    line-height: 1.7;
    overflow-wrap: anywhere;
}

.form-section {
    min-height: 75vh;
    padding: 45px 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #d4ecff, #f7fbff);
}

.form-box {
    width: 100%;
    max-width: 410px;
    background: white;
    padding: 32px;
    border-radius: 17px;
    box-shadow: 0 8px 30px #c3daef;
}

.form-box h2 {
    text-align: center;
    margin-bottom: 12px;
    color: #12396d;
}

.subtitle {
    text-align: center;
    color: #718198;
    margin-bottom: 25px;
}

.form-box label {
    display: block;
    font-weight: bold;
    margin: 15px 0 7px;
}

.form-box input {
    width: 100%;
    padding: 13px;
    border: 1px solid #c8d8e8;
    border-radius: 7px;
    font-size: 15px;
}

.form-box input:focus {
    outline: 2px solid #b5e1ff;
    border-color: #174c91;
}

.form-box button {
    width: 100%;
    margin: 20px 0 12px;
}

.form-box p {
    text-align: center;
    line-height: 1.8;
}

.form-box a {
    color: #174c91;
    font-weight: bold;
}

.message {
    max-width: 650px;
    margin: 20px auto;
    padding: 15px;
    border-radius: 8px;
    background: #d9f7e5;
    color: #17633b;
    text-align: center;
    font-weight: bold;
}

.error {
    background: #ffe3e3;
    color: #a12222;
}

.dashboard {
    padding: 45px 7%;
    min-height: 70vh;
    background: linear-gradient(135deg, #e0f1ff, #ffffff);
}

.dashboard h1 {
    margin-bottom: 15px;
    color: #12396d;
}

.dashboard > p {
    margin-bottom: 30px;
    line-height: 1.8;
}

footer {
    background: #102e59;
    color: white;
    text-align: center;
    padding: 22px;
    line-height: 1.8;
}

@media (max-width: 600px) {
    header {
        justify-content: center;
        text-align: center;
    }

    nav {
        justify-content: center;
    }

    .hero {
        text-align: center;
        padding: 40px 6%;
    }

    .hero img {
        height: 220px;
    }

    .form-box {
        padding: 25px 20px;
    }
}
</style>
</head>

<body>

<header>
    <div class="logo">🎓 Internship Portal</div>

    <nav>
        <a href="index.php">Home</a>

        <?php if (!empty($_SESSION['logged_in'])): ?>
            <a href="index.php?page=dashboard">Dashboard</a>
            <a href="index.php?logout=1">Logout</a>
        <?php else: ?>
            <a href="index.php?page=login">Login</a>
            <a href="index.php?page=register">Register</a>
        <?php endif; ?>
    </nav>
</header>

<?php if ($message !== ''): ?>
    <div class="message <?= strpos($message, 'Invalid') !== false ? 'error' : '' ?>">
        <?= h($message) ?>
    </div>
<?php endif; ?>

<?php if ($page === 'home'): ?>

<section class="hero">
    <div class="hero-content">
        <h1>Build Your Future With Internships</h1>

        <p>
            Discover internship opportunities, improve your skills,
            connect with companies and take the next step in your career.
        </p>

        <a class="btn" href="index.php?page=register">Get Started</a>
        <a class="btn" href="index.php?page=login">Student Login</a>
    </div>

    <img
        src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=900&q=80"
        alt="Students working together">
</section>

<section class="features">
    <h2>Explore Our Features</h2>

    <div class="cards">
        <div class="card">
            <div class="icon">👨‍🎓</div>
            <h3>Student Profile</h3>
            <p>Create your account and prepare for career opportunities.</p>
        </div>

        <div class="card">
            <div class="icon">🔍</div>
            <h3>Find Internships</h3>
            <p>Explore internship opportunities for your interests.</p>
        </div>

        <div class="card">
            <div class="icon">📝</div>
            <h3>Easy Applications</h3>
            <p>Manage your internship application journey.</p>
        </div>

        <div class="card">
            <div class="icon">📊</div>
            <h3>Track Progress</h3>
            <p>View your profile and dashboard information.</p>
        </div>
    </div>
</section>

<?php elseif ($page === 'register'): ?>

<section class="form-section">
    <form class="form-box" method="post" action="index.php?page=register">
        <h2>Create Account</h2>
        <p class="subtitle">Start your internship journey today.</p>

        <input type="hidden" name="action" value="register">

        <label for="name">Full Name</label>
        <input id="name" type="text" name="name" maxlength="100"
               placeholder="Enter your name" required>

        <label for="reg-email">Email Address</label>
        <input id="reg-email" type="email" name="email"
               placeholder="Enter your email" required>

        <label for="reg-password">Password</label>
        <input id="reg-password" type="password" name="password"
               minlength="6" placeholder="At least 6 characters" required>

        <button class="btn" type="submit">Register Now</button>

        <p>Already registered?
            <a href="index.php?page=login">Login here</a>
        </p>
    </form>
</section>

<?php elseif ($page === 'login'): ?>

<section class="form-section">
    <form class="form-box" method="post" action="index.php?page=login">
        <h2>Welcome Back!</h2>
        <p class="subtitle">Login to your student account.</p>

        <input type="hidden" name="action" value="login">

        <label for="login-email">Email Address</label>
        <input id="login-email" type="email" name="email"
               placeholder="Enter your email" required>

        <label for="login-password">Password</label>
        <input id="login-password" type="password" name="password"
               placeholder="Enter your password" required>

        <button class="btn" type="submit">Login</button>

        <p>New student?
            <a href="index.php?page=register">Create account</a>
        </p>
    </form>
</section>

<?php elseif ($page === 'dashboard' && !empty($_SESSION['logged_in'])): ?>

<section class="dashboard">
    <h1>🎉 Dashboard</h1>

    <p>
        Login Successful! Welcome,
        <strong><?= h($_SESSION['name']) ?></strong>.
        Your account is ready.
    </p>

    <div class="cards">
        <div class="card">
            <div class="icon">👤</div>
            <h3>My Profile</h3>
            <p><?= h($_SESSION['name']) ?></p>
            <p><?= h($_SESSION['email']) ?></p>
        </div>

        <div class="card">
            <div class="icon">🔍</div>
            <h3>Search Internships</h3>
            <p>Explore opportunities that match your interests.</p>
        </div>

        <div class="card">
            <div class="icon">📋</div>
            <h3>My Applications</h3>
            <p>Your application management section.</p>
        </div>

        <div class="card">
            <div class="icon">⭐</div>
            <h3>My Skills</h3>
            <p>Prepare your professional skills.</p>
        </div>
    </div>

    <p style="text-align:center;margin-top:30px;">
        <a class="btn" href="index.php?logout=1">Logout</a>
    </p>
</section>

<?php else: ?>

<section class="hero">
    <h1>Page Not Found</h1>
    <a class="btn" href="index.php">Return Home</a>
</section>

<?php endif; ?>

<footer>
    <p>© 2026 College Internship Portal</p>
    <p>Student Internship Management System</p>
</footer>

</body>
</html>