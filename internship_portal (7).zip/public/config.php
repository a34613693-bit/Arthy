<?php
// ---- Configuration: edit these to match your environment ----
define('DB_HOST', 'localhost');
define('DB_NAME', 'internship_portal');
define('DB_USER', 'root');
define('DB_PASS', '');
// URL path where the project lives (with trailing slash), e.g. '/internship_portal/'
define('BASE', '/internship_portal/');

const STATUSES = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected', 'Rejected'];

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function redirect(string $url): void { header('Location: ' . $url); exit; }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function is_staff(): bool { return in_array(current_user()['role'] ?? '', ['company', 'admin'], true); }

function require_role(string ...$roles): void {
    $u = current_user();
    if (!$u) { redirect(BASE . 'login.php'); }
    if (!in_array($u['role'], $roles, true)) { http_response_code(403); die('Access denied.'); }
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); }
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400); die('Invalid request token. Go back and try again.');
    }
}

function flash(string $type, string $msg): void { $_SESSION['flash'][] = [$type, $msg]; }
function status_class(string $s): string { return 'badge s-' . strtolower(str_replace(' ', '-', $s)); }

// Staff scoping: companies only see their own data, admins see everything.
function my_company_id(): ?int { return current_user()['company_id'] ?? null; }
function can_manage(int $companyId): bool {
    $u = current_user();
    return $u && ($u['role'] === 'admin' || ($u['role'] === 'company' && (int)$u['company_id'] === $companyId));
}
