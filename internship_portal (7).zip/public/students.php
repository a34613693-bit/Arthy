<?php
require __DIR__ . '/../config.php';
require_role('company', 'admin');
$q = trim($_GET['q'] ?? '');
$sql = "SELECT s.*, u.email, u.created_at, (SELECT GROUP_CONCAT(skill_name SEPARATOR ', ') FROM skills k WHERE k.student_id=s.id) AS skills
        FROM students s JOIN users u ON u.id=s.user_id";
$p = [];
if ($q !== '') { $sql .= ' WHERE s.full_name LIKE ? OR s.college LIKE ? OR u.email LIKE ? OR s.id IN (SELECT student_id FROM skills WHERE skill_name LIKE ?)'; $l = "%$q%"; $p = [$l, $l, $l, $l]; }
$sql .= ' ORDER BY u.created_at DESC';
$st = db()->prepare($sql); $st->execute($p); $rows = $st->fetchAll();
$pageTitle = 'Registered Students';
include __DIR__ . '/../includes/header.php';
?>
<h2>Registered Students (<?= count($rows) ?>)</h2>
<form class="filters" method="get"><input name="q" placeholder="Search by name, college, email or skill" value="<?= e($q) ?>"><button class="btn" type="submit">Search</button></form>
<div class="table-wrap"><table>
  <tr><th>Name</th><th>Email</th><th>College</th><th>Degree</th><th>CGPA</th><th>Skills</th><th>Resume</th></tr>
  <?php foreach ($rows as $r): ?>
  <tr><td><b><?= e($r['full_name']) ?></b></td><td><?= e($r['email']) ?></td><td><?= e($r['college'] ?: '—') ?></td>
      <td><?= e(trim(($r['degree'] ?: '') . ' ' . ($r['branch'] ?: '')) ?: '—') ?></td><td><?= e($r['cgpa'] ?: '—') ?></td>
      <td><?= e($r['skills'] ?: '—') ?></td>
      <td><?php if ($r['resume_link']): ?><a href="<?= e($r['resume_link']) ?>" target="_blank" rel="noopener noreferrer">View</a><?php else: ?>—<?php endif; ?></td></tr>
  <?php endforeach; if (!$rows) echo '<tr><td colspan="7" class="muted">No students found.</td></tr>'; ?>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
